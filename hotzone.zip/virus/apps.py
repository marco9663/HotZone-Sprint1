from django.apps import AppConfig


class VirusConfig(AppConfig):
    name = 'virus'
