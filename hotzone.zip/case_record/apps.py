from django.apps import AppConfig


class CaseRecordConfig(AppConfig):
    name = 'case_record'
