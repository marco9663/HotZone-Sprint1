from django.apps import AppConfig


class VisitedLocationConfig(AppConfig):
    name = 'visited_location'
